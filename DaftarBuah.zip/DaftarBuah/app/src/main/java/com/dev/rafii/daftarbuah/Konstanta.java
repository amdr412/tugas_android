package com.dev.rafii.daftarbuah;

public class Konstanta {
    public static final String DATANAMA = "datanama";
    public static final String DATAGAMBAR = "datagambar";
}
